#include "DBfetch.h"
#include "gui.h"
#include <iostream>
#include <modbus.h>
#include <vector>
#include <chrono>
#include <thread>
#include "PicknPlace.h"
#include "transformations.h"
#include "rotmat.h"
#include "matrix.h"

int main(int argc, char** argv){

//   Transformation trans(3,12);

//   trans.BaseToTarget(490.5, -600.4, -2.7, 2.743).print();




    QCoreApplication a(argc, argv);

    loadStuff();
    resizeStuff();
    createButtons();
    insertButtons();
    loadSounds();

    category.play();

    imgtext = "Our GUI";
    cv::namedWindow(imgtext);
    cv::setMouseCallback(imgtext, callBackFunc);

    cv::imshow(imgtext, imggui_resized);

    cv::waitKey(0);

    /* MODBUS COMMUNICATION */
    modbus mb = modbus("192.168.1.54", 502); mb.modbus_set_slave_id(1); mb.modbus_connect();    // Connects to robot via Modbus TCP/IP through IP-adress and Port

    std::vector<std::vector<int>> wordCoords = returnWordVec();     // Saves coords of choosen word

    // Variables to store positions for PLACING LEGOs
    uint16_t x_pos_place;
    uint16_t y_pos_place;

    // Variables to store positions for PICKING LEGOs
    uint16_t x_pos_pick;
    uint16_t y_pos_pick;

    // Variables to store z-coordinates for pick and place
    double z_pos_down1_LS = -31.4; //ÆNDRE
    double z_pos_down2_LS = 78.7;
    double z_pos_down3_LS = 197.5;
    double z_pos_down4_LS = 85.9;

    double z_pos_down1_WS = -29.7; //ÆNDRE
    double z_pos_down2_WS = 83.9;
    double z_pos_down3_WS = 198.7;
    double z_pos_down4_WS = 88.1;

    double z_pos_up1 = 69.7;
    double z_pos_up2 = 183.3;
    double z_pos_up3 = 298.1;
    double z_pos_up4 = 187.5;


    // Variables to store rotations
    double x_rot; //ÆNDRE
    double y_rot;
    double z_rot;

    double x_rot_1 = 0.15; //ÆNDRE
    double y_rot_1 = -0.05;
    double z_rot_1 = -1.62;

    double x_rot_2 = 1.31; //ÆNDRE
    double y_rot_2 = 3.29;
    double z_rot_2 = -2.35;

    double x_rot_3 = 1.56; //ÆNDRE
    double y_rot_3 = 2.93;
    double z_rot_3 = 0;

    double x_rot_4 = 0.63; //ÆNDRE
    double y_rot_4 = 1.57;
    double z_rot_4 = 1.16;

    // Variables to space between lego in transformation
    double LS_Gap = 16.25; //mm
    double WS_Gap = 8; //mm

    // Variables to LS T1, T2, T3, T4
    double LS_T1x = 1; //Ændre til rigtige positioner, det der skal stå i LS_TCP
    double LS_T1y = 1;
    double LS_T1z = 1;
    double LS_T1angle = 1;

    // Variables to check for-loops in pickNplace
    int check = 1;
    float rest = 1.0;

    std::vector<std::vector<double>> LS_TCP = {{366.0, -443.8, 2.7}, {478.8,-404.3, 2.7}, {372.2,-439.1,2.7}, {255.4,-479.8,2.7}}; //Ændre til rigtige mål for vinkel og origo af frame for hver "TCP"

    // Variables to WS T1, T2, T3, T4
    std::vector<std::vector<double>> WS_TCP = {{488.3, -604.3, 2.7}, {597.2,-569.8, 2.8}, {494.7,-598.3, 2.7}, {383.7,-650.3, 2.8}}; //Ændre til rigtige mål for vinkel og origo af frame for hver "TCP"


    std::vector<std::vector<int>> legoPos = legoPosFunc();


    uint16_t controlBit[1]; //Ændret
    uint16_t xcontrolBit[1];
    uint16_t ycontrolBit[1];
    uint16_t zcontrolBit[1];

    mb.modbus_read_holding_registers(128, 1, controlBit); //Ændret


///RESET REGISTERS:
//    mb.modbus_write_register(130, 0);
//    mb.modbus_write_register(131, 0);
//    mb.modbus_write_register(132, 0); //Ændre z-pos til over
//    mb.modbus_write_register(133, 0);
//    mb.modbus_write_register(134, 0);
//    mb.modbus_write_register(135, 0);
//    std::this_thread::sleep_for(std::chrono::seconds(1));

    mb.modbus_write_register(128, 0);
    std::this_thread::sleep_for(std::chrono::seconds(5));



    mb.modbus_write_register(128, 1);
    std::this_thread::sleep_for(std::chrono::seconds(1));      // Wait

    mb.modbus_write_register(128, 0);
    std::this_thread::sleep_for(std::chrono::seconds(1));



    int i_pick = 0;
    int j_pick = 0;


    for (int i = 0; i < wordCoords.size(); i++) {     // Iterates through vector of coords to print all x, and y for each letter in the chosen word
        std::cout << "Letter " << i+1 << ":" << std::endl;

        float length1 = wordCoords[i].size()/8; // 8, because fetch 2 coordinates at a time
        int length2 = length1;


        for (int j = 0; j < wordCoords[i].size(); j+=8) { // j+=4, because gets 4 Lego at a time

            bool run = true;    // Resets "run" bool

            if(check > length1){ // Checks if next for-loops shouldn't be 4 but less if there isn't 4 legos left in the letter.
                rest = length1 - length2;
            }

            /*-----------LEGO Opsamling-----------*/
            for(int k = 1; k < 4*rest; k++){ // rest = 1, but if only needs to fetch 2 legos it stops the loop after 2 because then rest = 0.5
                /* PICKING MOTION */

                x_pos_pick = legoPos[i_pick][j_pick];
                y_pos_pick = legoPos[i_pick][j_pick+1];
                j_pick = 0;
                i_pick++;

                std::cout << "x_pos_pick:  "<< x_pos_pick << std::endl;
                std::cout << "y_pos_pick:  "<< y_pos_pick << std::endl;
                double x_Coord;
                double y_Coord;
                double z_Coord_down;
                double z_Coord_up;
                double rotAngle;

                if(k==0){
                    x_Coord = LS_TCP[0][0];
                    y_Coord = LS_TCP[0][1];
                    z_Coord_down = z_pos_down1_LS;
                    z_Coord_up = z_pos_up1;
                    rotAngle = LS_TCP[0][2];
                    x_rot = x_rot_1;
                    y_rot = y_rot_1;
                    z_rot = z_rot_1;
                }

                else if(k==1){
                    x_Coord = LS_TCP[1][0];
                    y_Coord = LS_TCP[1][1];
                    z_Coord_down = z_pos_down2_LS;
                    z_Coord_up = z_pos_up2;
                    rotAngle = LS_TCP[1][2];
                    x_rot = x_rot_2;
                    y_rot = y_rot_2;
                    z_rot = z_rot_2;
                }

                else if(k==2){
                    x_Coord = LS_TCP[2][0];
                    y_Coord = LS_TCP[2][1];
                    z_Coord_down = z_pos_down3_LS;
                    z_Coord_up = z_pos_up3;
                    rotAngle = LS_TCP[2][2];
                    x_rot = x_rot_3;
                    y_rot = y_rot_3;
                    z_rot = z_rot_3;
                }

                else{
                    x_Coord = LS_TCP[3][0];
                    y_Coord = LS_TCP[3][1];
                    z_Coord_down = z_pos_down4_LS;
                    z_Coord_up = z_pos_up4;
                    rotAngle = LS_TCP[3][2];
                    x_rot = x_rot_4;
                    y_rot = y_rot_4;
                    z_rot = z_rot_4;
                }



                // HOVER LS - Above LEGO piece WO. LEGO piece
                run = true; // Resets "run" bool
                while(run) {    // While-loop runs until robot has finished current task

                    Transformation TransPick(x_pos_pick, y_pos_pick);
                    Matrix B_LS_P = TransPick.BaseToTarget(x_Coord, y_Coord, z_Coord_down, rotAngle, LS_Gap);

                    /* Writing positions to robot registers */
                    mb.modbus_read_holding_registers(128, 1, controlBit);
                    std::this_thread::sleep_for(std::chrono::seconds(1));
//                    //TEST
//                    std::this_thread::sleep_for(std::chrono::seconds(1));
//                    mb.modbus_write_register(128, 0);
//                    std::this_thread::sleep_for(std::chrono::seconds(1));

                    while(controlBit[0] == 0) {
                        std::this_thread::sleep_for(std::chrono::seconds(1));       // Wait

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos ready for sending, controlBit = " << controlBit[0] << std::endl;

                        mb.modbus_write_register(130, B_LS_P(0,0)*10);
                        mb.modbus_write_register(131, B_LS_P(1,0)*10);
                        mb.modbus_write_register(132, z_Coord_up*10); //Ændre z-pos til over
                        mb.modbus_write_register(133, x_rot*100);
                        mb.modbus_write_register(134, y_rot*100);
                        mb.modbus_write_register(135, z_rot*100);
                        mb.modbus_write_register(128, 1);

                        std::this_thread::sleep_for(std::chrono::seconds(1));       // Wait

                        mb.modbus_read_holding_registers(130, 1, xcontrolBit);
                        mb.modbus_read_holding_registers(131, 1, ycontrolBit);
                        mb.modbus_read_holding_registers(132, 1, zcontrolBit);

                        std::this_thread::sleep_for(std::chrono::seconds(1));       // Wait
                        std::cout << "---------------------------------------------------------" << std::endl;
                        std::cout << "HOVER1: " << std::endl;
                        B_LS_P.print();
                        std::cout << "Xregister = " << xcontrolBit[0] << std::endl;
                        std::cout << "Yregister = " << ycontrolBit[0] << std::endl;
                        std::cout << "Zregister" << zcontrolBit[0] << std::endl;

                        std::cout << "x_pos: " <<  B_LS_P(0,0)*10 << std::endl;
                        std::cout << "y_pos: " <<  B_LS_P(1,0)*10 << std::endl;
                        std::cout << "z_pos: " <<  z_Coord_up*10 << std::endl;
                        std::cout << "xrot: " << x_rot << std::endl;
                        std::cout << "yrot: " << y_rot << std::endl;
                        std::cout << "zrot: " << z_rot << std::endl;

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos sendt, controlBit = " << controlBit[0] << std::endl;
                        std::cout << "---------------------------------------------------------" << std::endl;

                        run = false;    // Set "run" bool for next pos to be calculated
                    }
                }

                        std::this_thread::sleep_for(std::chrono::seconds(1));       // Wait

                // GRAB - Grab LEGO piece
                run = true;     // Resets "run" bool
                while(run) {    // While-loop runs until robot has finished current task

                    Transformation TransPick(x_pos_pick, y_pos_pick);
                    Matrix B_LS_P = TransPick.BaseToTarget(x_Coord, y_Coord, z_Coord_down, rotAngle, LS_Gap);

                    /* Writing positions to robot registers */
                    mb.modbus_read_holding_registers(128, 1, controlBit);

//                    //TEST
//                    std::this_thread::sleep_for(std::chrono::seconds(1));
//                    mb.modbus_write_register(128, 0);
//                    std::this_thread::sleep_for(std::chrono::seconds(1));

                    while(controlBit[0] == 0) {
                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos ready for sending, controlBit = " << controlBit[0] << std::endl;

                        mb.modbus_write_register(130, B_LS_P(0,0)*10);
                        mb.modbus_write_register(131, B_LS_P(1,0)*10);
                        mb.modbus_write_register(132, B_LS_P(2,0)*10);
                        mb.modbus_write_register(133, x_rot*100);
                        mb.modbus_write_register(134, y_rot*100);
                        mb.modbus_write_register(135, z_rot*100);
                        mb.modbus_write_register(128, 1);

                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait
                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(130, 1, xcontrolBit);
                        mb.modbus_read_holding_registers(131, 1, ycontrolBit);
                        mb.modbus_read_holding_registers(132, 1, zcontrolBit);

                        std::this_thread::sleep_for(std::chrono::seconds(1));       // Wait
                        std::cout << "---------------------------------------------------------" << std::endl;
                        std::cout << "GRAB: " << std::endl;
                        B_LS_P.print();
                        std::cout << "Xregister = " << xcontrolBit[0] << std::endl;
                        std::cout << "Yregister = " << ycontrolBit[0] << std::endl;
                        std::cout << "Zregister" << zcontrolBit[0] << std::endl;

                        std::cout << "x_pos: " <<  B_LS_P(0,0)*10 << std::endl;
                        std::cout << "y_pos: " <<  B_LS_P(1,0)*10 << std::endl;
                        std::cout << "z_pos: " <<  B_LS_P(2,0)*10 << std::endl;
                        std::cout << "xrot: " << x_rot << std::endl;
                        std::cout << "yrot: " << y_rot << std::endl;
                        std::cout << "zrot: " << z_rot << std::endl;

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos sendt, controlBit = " << controlBit[0] << std::endl;
                        std::cout << "---------------------------------------------------------" << std::endl;

                        run = false;    // Set "run" bool for next pos to be calculated

                        std::this_thread::sleep_for(std::chrono::seconds(1));       // Wait
                    }
                }
                //Lav direkte op bevægelse (KOPIER første HOVER igen!! hernede, så den gåt op igen uden rotation -> robot skal ikke lave transformation samme tid med løft!!)

                // HOVER LS - Above LEGO piece WO. LEGO piece
                run = true;
                while(run) {    // While-loop runs until robot has finished current task

//                    //TEST
//                    std::this_thread::sleep_for(std::chrono::seconds(1));
//                    mb.modbus_write_register(128, 0);
//                    std::this_thread::sleep_for(std::chrono::seconds(1));

                    Transformation TransPick(x_pos_pick, y_pos_pick);
                    Matrix B_LS_P = TransPick.BaseToTarget(x_Coord, y_Coord, z_Coord_down, rotAngle, LS_Gap);

                    /* Writing positions to robot registers */
                    mb.modbus_read_holding_registers(128, 1, controlBit);

                    while(controlBit[0] == 0) {
                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos ready for sending, controlBit = " << controlBit[0] << std::endl;

                        mb.modbus_write_register(130, B_LS_P(0,0)*10);
                        mb.modbus_write_register(131, B_LS_P(1,0)*10);
                        mb.modbus_write_register(132, z_Coord_up*10); //Ændre z-pos til over
                        mb.modbus_write_register(133, x_rot*100);
                        mb.modbus_write_register(134, y_rot*100);
                        mb.modbus_write_register(135, z_rot*100);
                        mb.modbus_write_register(128, 1);

                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(130, 1, xcontrolBit);
                        mb.modbus_read_holding_registers(131, 1, ycontrolBit);
                        mb.modbus_read_holding_registers(132, 1, zcontrolBit);

                        std::this_thread::sleep_for(std::chrono::seconds(1));       // Wait

                        std::cout << "---------------------------------------------------------" << std::endl;
                        std::cout << "HOVER2: " << std::endl;
                        B_LS_P.print();
                        std::cout << "Xregister = " << xcontrolBit[0] << std::endl;
                        std::cout << "Yregister = " << ycontrolBit[0] << std::endl;
                        std::cout << "Zregister" << zcontrolBit[0] << std::endl;

                        std::cout << "x_pos: " <<  B_LS_P(0,0)*10 << std::endl;
                        std::cout << "y_pos: " <<  B_LS_P(1,0)*10 << std::endl;
                        std::cout << "z_pos: " <<  z_Coord_up*10 << std::endl;
                        std::cout << "xrot: " << x_rot << std::endl;
                        std::cout << "yrot: " << y_rot << std::endl;
                        std::cout << "zrot: " << z_rot << std::endl;

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos sendt, controlBit = " << controlBit[0] << std::endl;
                        std::cout << "---------------------------------------------------------" << std::endl;

                        run = false;    // Set "run" bool for next pos to be calculated

                        std::this_thread::sleep_for(std::chrono::seconds(1));       // Wait
                    }
                }
            }


//            // HOVER LS - Above W. LEGO piece FORKERT!!!!!!
//            run = true;     // Resets "run" bool
//            Transformation TransPick(x_pos_pick, y_pos_pick);
//            Matrix B_LS_P = TransPick.BaseToTarget(LS_TCP[3][0], LS_TCP[3][1], LS_TCP[3][2], LS_TCP[3][3], LS_Gap);

//            while(run) {    // While-loop runs until robot has finished current task

//                /* Writing positions to robot registers */
//                mb.modbus_read_holding_registers(128, 1, controlBit);
//                while(controlBit[0] == 0) {
//                    std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

//                    mb.modbus_read_holding_registers(128, 1, controlBit);
//                    std::cout << "Pos ready for sending, controlBit = " << controlBit[0] << std::endl;

//                    mb.modbus_write_register(130, B_LS_P(0,0)*100);
//                    mb.modbus_write_register(131, B_LS_P(1,0)*100);
//                    mb.modbus_write_register(132, B_LS_P(2,0)*100); //Ændre z-pos til over
//                    mb.modbus_write_register(133, x_rot_4*100);
//                    mb.modbus_write_register(134, y_rot_4*100);
//                    mb.modbus_write_register(135, z_rot_4*100);
//                    mb.modbus_write_register(128, 1);

//                    std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

//                    mb.modbus_read_holding_registers(128, 1, controlBit);
//                    std::cout << "Pos sendt, controlBit = " << controlBit[0] << std::endl;

//                    run = false;    // Set "run" bool for next pos to be calculated
//                }
//            }

        /*--------------Placering af LEGO-------------*/
            for(int l = 0; l < 8*rest; l+=2){
                /* PLACING MOTION */
                // x-coord
                x_pos_place = wordCoords[i][j+l]; // Ikke rigtigt??
                std::cout << "x(" << x_pos_place << ")" << " ";

                // y-coord
                y_pos_place = wordCoords[i][j+l+1]; //Ikke rigtigt??
                std::cout << "y(" << y_pos_place << ")" << std::endl;

                double x_Coord;
                double y_Coord;
                double z_Coord_down;
                double z_Coord_up;
                double rotAngle;

                if(l==0){
                    x_Coord = WS_TCP[0][0];
                    y_Coord = WS_TCP[0][1];
                    z_Coord_down = z_pos_down1_WS;
                    z_Coord_up = z_pos_up1;
                    rotAngle = WS_TCP[0][2];
                    x_rot = x_rot_1;
                    y_rot = y_rot_1;
                    z_rot = z_rot_1;

                }

                else if(l==2){
                    x_Coord = WS_TCP[1][0];
                    y_Coord = WS_TCP[1][1];
                    z_Coord_down = z_pos_down2_WS;
                    z_Coord_up = z_pos_up2;
                    rotAngle = WS_TCP[1][2];
                    x_rot = x_rot_2;
                    y_rot = y_rot_2;
                    z_rot = z_rot_2;
                }

                else if(l==4){
                    x_Coord = WS_TCP[2][0];
                    y_Coord = WS_TCP[2][1];
                    z_Coord_down = z_pos_down3_WS;
                    z_Coord_up = z_pos_up3;
                    rotAngle = WS_TCP[2][2];
                    x_rot = x_rot_3;
                    y_rot = y_rot_3;
                    z_rot = z_rot_3;
                }

                else{
                    x_Coord = WS_TCP[3][0];
                    y_Coord = WS_TCP[3][1];
                    z_Coord_down = z_pos_down4_WS;
                    z_Coord_up = z_pos_up4;
                    rotAngle = WS_TCP[3][2];
                    x_rot = x_rot_4;
                    y_rot = y_rot_4;
                    z_rot = z_rot_4;
                }


                // HOVER WS - Above workspace W. LEGO piece
                run = true;
                while(run) {        // While-loop runs until robot has finished current task

                    Transformation TransPlace(x_pos_place, y_pos_place);
                    Matrix B_WS_P = TransPlace.BaseToTarget(x_Coord, y_Coord, z_Coord_up, rotAngle, WS_Gap);

                    /* Writing positions to robot registers */
                    mb.modbus_read_holding_registers(128, 1, controlBit);
                    while(controlBit[0] == 0) {
                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos ready for sending, controlBit = " << controlBit[0] << std::endl;

                        mb.modbus_write_register(130, B_WS_P(0,0)*10);
                        mb.modbus_write_register(131, B_WS_P(1,0)*10);
                        mb.modbus_write_register(132, B_WS_P(2,0)*10); //Ændre z-pos til over
                        mb.modbus_write_register(133, x_rot*100);
                        mb.modbus_write_register(134, y_rot*100);
                        mb.modbus_write_register(135, z_rot*100);
                        mb.modbus_write_register(128, 1);

                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos sendt, controlBit = " << controlBit[0] << std::endl;

                        run = false;    // Set "run" bool for next pos to be calculated
                    }
                }

                // PLACE - Placing LEGO piece
                run = true;
                while(run) {        // While-loop runs until robot has finished current task

                    Transformation TransPlace(x_pos_place, y_pos_place);
                    Matrix B_WS_P = TransPlace.BaseToTarget(x_Coord, y_Coord, z_Coord_down, rotAngle, WS_Gap);

                    /* Writing positions to robot registers */
                    mb.modbus_read_holding_registers(128, 1, controlBit);
                    while(controlBit[0] == 0) {
                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos ready for sending, controlBit = " << controlBit[0] << std::endl;

                        mb.modbus_write_register(130, B_WS_P(0,0)*10);
                        mb.modbus_write_register(131, B_WS_P(1,0)*10);
                        mb.modbus_write_register(132, B_WS_P(2,0)*10); //Ændre z-pos til down
                        mb.modbus_write_register(133, x_rot*100);
                        mb.modbus_write_register(134, y_rot*100);
                        mb.modbus_write_register(135, z_rot*100);
                        mb.modbus_write_register(128, 1);

                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos sendt, controlBit = " << controlBit[0] << std::endl;

                        run = false;    // Set "run" bool for next pos to be calculated
                    }
                }
                //Lav direkte op bevægelse (KOPIER første HOVER igen!! hernede, så den gåt op igen uden rotation -> robot skal ikke lave transformation samme tid med løft!!)
                // HOVER WS - Above workspace W. LEGO piece
                run = true;
                while(run) {        // While-loop runs until robot has finished current task

                    Transformation TransPlace(x_pos_place, y_pos_place);
                    Matrix B_WS_P = TransPlace.BaseToTarget(x_Coord, y_Coord, z_Coord_up, rotAngle, WS_Gap);

                    /* Writing positions to robot registers */
                    mb.modbus_read_holding_registers(128, 1, controlBit);
                    while(controlBit[0] == 0) {
                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos ready for sending, controlBit = " << controlBit[0] << std::endl;

                        mb.modbus_write_register(130, B_WS_P(0,0)*10);
                        mb.modbus_write_register(131, B_WS_P(1,0)*10);
                        mb.modbus_write_register(132, B_WS_P(2,0)*10); //Ændre z-pos til over
                        mb.modbus_write_register(133, x_rot*100);
                        mb.modbus_write_register(134, y_rot*100);
                        mb.modbus_write_register(135, z_rot*100);
                        mb.modbus_write_register(128, 1);

                        std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

                        mb.modbus_read_holding_registers(128, 1, controlBit);
                        std::cout << "Pos sendt, controlBit = " << controlBit[0] << std::endl;

                        run = false;    // Set "run" bool for next pos to be calculated
                    }
                }

            }
////FORKERT
//            Transformation TransPlace(x_pos_place, y_pos_place);
//            Matrix B_WS_P = TransPick.BaseToTarget(WS_TCP[3][0], WS_TCP[3][1], WS_TCP[3][2], WS_TCP[3][3], WS_Gap);
//            // HOVER WS - Above workpiece WO. LEGO piece
//            run = true;
//            while(run) {        // While-loop runs until robot has finished current task

//                /* Writing positions to robot registers */
//                mb.modbus_read_holding_registers(128, 1, controlBit);
//                while(controlBit[0] == 0) {
//                    std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

//                    mb.modbus_read_holding_registers(128, 1, controlBit);
//                    std::cout << "Pos ready for sending, controlBit = " << controlBit[0] << std::endl;

//                    mb.modbus_write_register(130, B_WS_P(0,0)*100);
//                    mb.modbus_write_register(131, B_WS_P(1,0)*100);
//                    mb.modbus_write_register(132, B_WS_P(2,0)*100); //Ændre z-pos til over
//                    mb.modbus_write_register(133, x_rot*100);
//                    mb.modbus_write_register(134, y_rot*100);
//                    mb.modbus_write_register(135, z_rot*100);
//                    mb.modbus_write_register(128, 1);

//                    std::this_thread::sleep_for(std::chrono::milliseconds(1));       // Wait

//                    mb.modbus_read_holding_registers(128, 1, controlBit);
//                    std::cout << "Pos sendt, controlBit = " << controlBit[0] << std::endl;

//                    run = false;    // Set "run" bool for next pos to be calculated
//                }
//            }

            check++; //Used to check
        }

        std::cout << std::endl;
    }

    // close connection and free the memory
    mb.modbus_close();

    return 0;
}
